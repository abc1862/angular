
document.getElementsByTagName('p')[2].innerHTML += headVar + bodyVar;