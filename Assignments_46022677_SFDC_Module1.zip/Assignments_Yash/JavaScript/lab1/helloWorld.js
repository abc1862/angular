sayHello = () => {
    document.getElementsByTagName('p')[0].innerHTML = 'Hello World';
}