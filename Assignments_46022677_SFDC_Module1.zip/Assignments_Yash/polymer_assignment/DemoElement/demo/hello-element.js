import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-icons/iron-icons.js';

class HelloElement extends PolymerElement{
    static get template() {
        return html`
        <h3>Welcome to polymer 3</h3>
        `}
        static get properties(){
            return {
                name:{
                    type:String,
                    value:'Rahul'
                },salary:{
                    type:Number,
                    value:10000.11
                }
                
            };
        }
}
customElements.define('hello-element', HelloElement);