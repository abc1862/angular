import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  id1:number=null;
  name:string="";
  salary:number=null;
  dept:string="";

  handle(){
    alert(this.id1 + " " + this.name + " " + this.salary + " " + this.dept);
  }
  title = 'Lab1';
}
