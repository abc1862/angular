import { Component } from '@angular/core';
import { BookService } from './service/book.service';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'four';


  constructor(private ob:BookService){ }
    booksData;
    ngOnInit(){
      this.ob.getData().subscribe(data=>{this.booksData=data;})
    }

  
}
