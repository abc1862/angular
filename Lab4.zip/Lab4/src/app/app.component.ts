import { Component, OnInit } from '@angular/core';
import { BookService } from './services/book.service';
import { Book } from './book';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  id:string=null;
  year:string=null;
  title:string=null;
  author:string=null;

  books: Book[]=[];

  constructor(private bookservice : BookService){}

  ngOnInit(){
    this.bookservice.getJSON().subscribe(data => {
         this.books = data;
         console.log(this.books);
     });
  }
}
