import { Component } from '@angular/core';
import {BookService} from './service/book.service';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lfourone';
  constructor(private ob:BookService){}
  booksData;
  sid(){
    this.booksData.sort(function(a,b){
      return a.id-b.id;
    })
  }
  stitle(){
    this.booksData.sort(function(a,b)
  {
    let n1=a.title.toLowerCase();
    let n2=b.title.toLowerCase();
    if(n1>n2) return 1;
    if(n2>n1) return -1;
    return 0;
  })
  }
  sauthor(){
    this.booksData.sort(function(a,b)
  {
    let n1=a.author.toLowerCase();
    let n2=b.author.toLowerCase();
    if(n1>n2) return 1;
    if(n2>n1) return -1;
    return 0;
  })

  }
  syop(){
 
    this.booksData.sort(function(a,b){
      return a.year-b.year;
    })
  }
  delete(i){
    this.booksData.splice(this.booksData.indexOf(i),1);
  }
  ngOnInit(){
    this.ob.getData().subscribe(data=>{this.booksData=data;})
  }
}
