import { Component } from '@angular/core';
import { FormGroup, FormControl,FormBuilder,Validators} from '@angular/forms';
import { product } from './product';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  ugabugbuga;
  category: string[] = [
    'Electronics',
    'Grocery',
    'Mobile',
    'Cloth'
  ];
  checkedList = [false, false, false, false];
  
  online:any[]=['Yes','No'];
  products:any[]=[
    { id:1,
      value:'BigBazar'
    },
    { id:2,
      value:'D-Mart'
    },
    { id:3,
      value:'Alliance'
    },
    { id:4,
      value:'Mega Store'
    }];
   userform: FormGroup; 
   pdt = new product();
   selected = [];
  
  constructor(){}
  ngOnInit(){
  }
  validate(userforms){
      console.log("Form Submitted!");
      // this.pdt.id = userforms.id.value;
      // this.pdt.name = userforms.name.value;
      // this.pdt.cost = userforms.cost.value;
      // this.pdt.online = userforms.l.value;
      // this.pdt.category =userforms.Category.value;
      // this.pdt.store.bigbazar = this.checkedList[0];
      // this.pdt.store.dmart = this.checkedList[1];
      // this.pdt.store.Reliance = this.checkedList[2];
      // this.pdt.store.MegaStore = this.checkedList[3];
      // for(var i=0; i<4; i++) {
      //   if(this.checkedList[i]==true) {
      //     this.pdt.store.push(this.products[i].value);
      //   }
      // }
      this.pdt.store = this.checkedList;



      console.log(userforms.value);

      //console.log((this.pdt));
      console.log(this.checkedList);
  }
  onCheckboxChange(option, event) {
    if(event.target.checked) {
      this.checkedList.splice(option.id-1, 1, true);
    } else {
    for(var i=0 ; i < this.products.length; i++) {
      if(this.checkedList[i] == option.id) {
        this.checkedList.splice(i,1,false);
     }
   }
 }
}
}
